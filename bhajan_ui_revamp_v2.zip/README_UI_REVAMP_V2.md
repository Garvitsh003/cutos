# Bhajan Marg AI — devotional UI revamp v2

Changes in this version:
- 108 mala dots instead of 27.
- Naam-jap counter and naam-selection area merged into one card.
- Built-in naam choices: Radha, Radhe Radhe, Shri Harivansh, Ram, Sita Ram, Saamb Sadashiv, Krishna, Hari.
- Custom naam-jap option.
- Selected naam persists in the browser.
- Jap counts are stored separately per selected naam and per conversation.
- Search overlay shows the selected naam.
- Simpler Hindi throughout the visible UI.
- Removed the extra “follow-up” note under the chat heading.
- Simplified disclaimer and footer language.
- No Sai name in the background or options.

Apply from the project root:

```bash
cp web/index.html web/index.html.before-jap-v2
cp app/static/index.html app/static/index.html.before-jap-v2
unzip -o ~/Downloads/bhajan_ui_revamp_v2.zip -d .
```

Then commit:

```bash
git add web/index.html app/static/index.html
git commit -m "Improve naam jap UI with 108 mala and custom naam"
git push origin main
```
